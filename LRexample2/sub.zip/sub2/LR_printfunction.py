#!/usr/bin/python
# -*- coding: UTF-8 -*-
# Print result

def printResult(MSE):    
    
    return "Mean Squared Error = " + str(MSE)